#include <iostream>
using namespace std;

bool primeNumber(int);
// finds and prints all primes less than n
void printPrimes(int n);


int main()
{
  int x;
  cout << " Input what number you would like to check up until: ";
  cin >> x;
  printPrimes(x);
  return 0;
}

bool primeNumber(int n) {
   bool prime = true;

   for(int i = 2; i <= n/2; i++) {
      if (n % i == 0) {
         prime = false;
         break;
      }
   }  
   return prime;
}
void printPrimes(int n)
{
   bool prime;
   for(int i = 1; i < n; i++) {
     
      prime = primeNumber(i);

      if(prime == true)
         cout<<i<<" " << " ";
   }
}