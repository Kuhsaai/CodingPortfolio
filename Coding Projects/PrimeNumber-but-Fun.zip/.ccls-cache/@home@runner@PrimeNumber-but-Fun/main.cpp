#include <iostream>
using namespace std;
int primeNumber(int);int primeNumber(int n) {bool prime = true;for(int i = 2; i <= n/2; i++){if (n % i == 0) {prime = false;break;}}return prime;}int main(){bool prime;for(int n = 1; n < 100000; n++) {prime = primeNumber(n);if(prime == true)cout<<n<<" ";}return 0;}
//time to have some fun and see just how ugly I can make this code look >:D