const card1 = document.getElementById('card1');
const card2 = document.getElementById('card2');
const project1 = document.getElementById('project1');
const project2 = document.getElementById('project2');

card1.addEventListener('click', () => {
  project1.scrollIntoView({ behavior: 'smooth' });
});

card2.addEventListener('click', () => {
  project2.scrollIntoView({ behavior: 'smooth' });
});
